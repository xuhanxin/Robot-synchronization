
"use strict";

let ObstacleArrayMsg = require('./ObstacleArrayMsg.js');
let ObstacleMsg = require('./ObstacleMsg.js');

module.exports = {
  ObstacleArrayMsg: ObstacleArrayMsg,
  ObstacleMsg: ObstacleMsg,
};

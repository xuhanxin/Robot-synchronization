
"use strict";

let TwoInts = require('./TwoInts.js')

module.exports = {
  TwoInts: TwoInts,
};

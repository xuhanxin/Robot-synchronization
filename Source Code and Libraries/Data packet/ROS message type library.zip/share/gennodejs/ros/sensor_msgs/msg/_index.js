
"use strict";

let Temperature = require('./Temperature.js');
let JointState = require('./JointState.js');
let MultiEchoLaserScan = require('./MultiEchoLaserScan.js');
let Joy = require('./Joy.js');
let BatteryState = require('./BatteryState.js');
let Imu = require('./Imu.js');
let LaserEcho = require('./LaserEcho.js');
let JoyFeedbackArray = require('./JoyFeedbackArray.js');
let RegionOfInterest = require('./RegionOfInterest.js');
let PointCloud2 = require('./PointCloud2.js');
let FluidPressure = require('./FluidPressure.js');
let NavSatFix = require('./NavSatFix.js');
let PointCloud = require('./PointCloud.js');
let PointField = require('./PointField.js');
let JoyFeedback = require('./JoyFeedback.js');
let LaserScan = require('./LaserScan.js');
let ChannelFloat32 = require('./ChannelFloat32.js');
let Illuminance = require('./Illuminance.js');
let Image = require('./Image.js');
let CameraInfo = require('./CameraInfo.js');
let NavSatStatus = require('./NavSatStatus.js');
let Range = require('./Range.js');
let TimeReference = require('./TimeReference.js');
let RelativeHumidity = require('./RelativeHumidity.js');
let CompressedImage = require('./CompressedImage.js');
let MultiDOFJointState = require('./MultiDOFJointState.js');
let MagneticField = require('./MagneticField.js');

module.exports = {
  Temperature: Temperature,
  JointState: JointState,
  MultiEchoLaserScan: MultiEchoLaserScan,
  Joy: Joy,
  BatteryState: BatteryState,
  Imu: Imu,
  LaserEcho: LaserEcho,
  JoyFeedbackArray: JoyFeedbackArray,
  RegionOfInterest: RegionOfInterest,
  PointCloud2: PointCloud2,
  FluidPressure: FluidPressure,
  NavSatFix: NavSatFix,
  PointCloud: PointCloud,
  PointField: PointField,
  JoyFeedback: JoyFeedback,
  LaserScan: LaserScan,
  ChannelFloat32: ChannelFloat32,
  Illuminance: Illuminance,
  Image: Image,
  CameraInfo: CameraInfo,
  NavSatStatus: NavSatStatus,
  Range: Range,
  TimeReference: TimeReference,
  RelativeHumidity: RelativeHumidity,
  CompressedImage: CompressedImage,
  MultiDOFJointState: MultiDOFJointState,
  MagneticField: MagneticField,
};

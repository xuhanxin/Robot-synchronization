
"use strict";

let Authentication = require('./Authentication.js')

module.exports = {
  Authentication: Authentication,
};

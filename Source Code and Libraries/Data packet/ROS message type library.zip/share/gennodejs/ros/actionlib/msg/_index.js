
"use strict";

let TwoIntsActionFeedback = require('./TwoIntsActionFeedback.js');
let TwoIntsResult = require('./TwoIntsResult.js');
let TestGoal = require('./TestGoal.js');
let TwoIntsGoal = require('./TwoIntsGoal.js');
let TwoIntsActionGoal = require('./TwoIntsActionGoal.js');
let TestActionGoal = require('./TestActionGoal.js');
let TestRequestResult = require('./TestRequestResult.js');
let TestResult = require('./TestResult.js');
let TestActionResult = require('./TestActionResult.js');
let TwoIntsActionResult = require('./TwoIntsActionResult.js');
let TestRequestActionGoal = require('./TestRequestActionGoal.js');
let TestFeedback = require('./TestFeedback.js');
let TestActionFeedback = require('./TestActionFeedback.js');
let TestRequestFeedback = require('./TestRequestFeedback.js');
let TestRequestAction = require('./TestRequestAction.js');
let TwoIntsFeedback = require('./TwoIntsFeedback.js');
let TestRequestActionResult = require('./TestRequestActionResult.js');
let TestAction = require('./TestAction.js');
let TwoIntsAction = require('./TwoIntsAction.js');
let TestRequestGoal = require('./TestRequestGoal.js');
let TestRequestActionFeedback = require('./TestRequestActionFeedback.js');

module.exports = {
  TwoIntsActionFeedback: TwoIntsActionFeedback,
  TwoIntsResult: TwoIntsResult,
  TestGoal: TestGoal,
  TwoIntsGoal: TwoIntsGoal,
  TwoIntsActionGoal: TwoIntsActionGoal,
  TestActionGoal: TestActionGoal,
  TestRequestResult: TestRequestResult,
  TestResult: TestResult,
  TestActionResult: TestActionResult,
  TwoIntsActionResult: TwoIntsActionResult,
  TestRequestActionGoal: TestRequestActionGoal,
  TestFeedback: TestFeedback,
  TestActionFeedback: TestActionFeedback,
  TestRequestFeedback: TestRequestFeedback,
  TestRequestAction: TestRequestAction,
  TwoIntsFeedback: TwoIntsFeedback,
  TestRequestActionResult: TestRequestActionResult,
  TestAction: TestAction,
  TwoIntsAction: TwoIntsAction,
  TestRequestGoal: TestRequestGoal,
  TestRequestActionFeedback: TestRequestActionFeedback,
};
